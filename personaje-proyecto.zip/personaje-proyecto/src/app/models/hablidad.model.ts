export interface Habilidad {
  nombre: string;
  valor: number;
}
