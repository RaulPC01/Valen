export interface Clase {
  nombre: string;
  descripcion: string;
  puntosDeGolpe: number;
  habilidadesPrimarias: string[];
  habilidadesDeSalvacion: string[];
  nivel: number;
}
