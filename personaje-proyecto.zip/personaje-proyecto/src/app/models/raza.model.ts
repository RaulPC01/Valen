export interface Raza {
  nombre: string;
  descripcion: string;
  rasgos: string;
}
