import { Clase } from "./clase.model";
import { Habilidad } from "./hablidad.model";
import { Raza } from "./raza.model";

export interface Personaje {
  nombre: string;
  raza: Raza;
  clase: Clase;
  habilidades: Habilidad[];
}
