import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { AppComponent } from './app.component';
import { SelectorRazaComponent } from './selector-raza/selector-raza.component';
import { SelectorClaseComponent } from './selector-clase/selector-clase.component';

@NgModule({
  declarations: [
    AppComponent,
    SelectorRazaComponent,
    SelectorClaseComponent
  ],
  imports: [
    BrowserModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
