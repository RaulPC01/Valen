import { Component, Output, EventEmitter } from '@angular/core';
import { Raza } from '../models/raza.model';

@Component({
  selector: 'app-selector-raza',
  templateUrl: './selector-raza.component.html',
  styleUrls: ['./selector-raza.component.css']
})
export class SelectorRazaComponent {
  @Output() razaSeleccionada = new EventEmitter<Raza>();

  razas: Raza[] = [
    { nombre: 'Humano', descripcion: 'Versátil y ambicioso', rasgos: 'Adaptabilidad' },
    { nombre: 'Elfo', descripcion: 'Ágil y perceptivo', rasgos: 'Visión en la oscuridad' },
    { nombre: 'Enano', descripcion: 'Resistente y trabajador', rasgos: 'Constitución robusta' },
    { nombre: 'Orco', descripcion: 'Fuerte y feroz', rasgos: 'Fuerza bruta' }
  ];

  seleccionarRaza(raza: Raza) {
    this.razaSeleccionada.emit(raza);
    this.razas = this.razas.filter(r => r === raza);
  }
}
