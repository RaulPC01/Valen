import { ComponentFixture, TestBed } from '@angular/core/testing';

import { SelectorRazaComponent } from './selector-raza.component';

describe('SelectorRazaComponent', () => {
  let component: SelectorRazaComponent;
  let fixture: ComponentFixture<SelectorRazaComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [SelectorRazaComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(SelectorRazaComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
