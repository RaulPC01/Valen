import { Component } from '@angular/core';
import { Personaje } from './models/personaje.model';
import { Raza } from './models/raza.model';
import { Clase } from './models/clase.model';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  personaje: Personaje = {
    nombre: 'Nombre del Personaje',
    raza: { nombre: '', descripcion: '', rasgos: '' },
    clase: { nombre: '', descripcion: '', puntosDeGolpe: 0, habilidadesPrimarias: [], habilidadesDeSalvacion: [], nivel: 0 },
    habilidades: []
  };

  actualizarRaza(raza: Raza) {
    this.personaje.raza = raza;
  }

  actualizarClase(clase: Clase) {
    this.personaje.clase = clase;
  }
}
