import { Component, Output, EventEmitter } from '@angular/core';
import { Clase } from '../models/clase.model';

@Component({
  selector: 'app-selector-clase',
  templateUrl: './selector-clase.component.html',
  styleUrls: ['./selector-clase.component.css']
})
export class SelectorClaseComponent {
  @Output() claseSeleccionada = new EventEmitter<Clase>();

  clases: Clase[] = [
    { nombre: 'Guerrero', descripcion: 'Fuerte y resistente', puntosDeGolpe: 100, habilidadesPrimarias: ['Ataque fuerte'], habilidadesDeSalvacion: ['Resistencia'], nivel: 1 },
    { nombre: 'Mago', descripcion: 'Experto en magia', puntosDeGolpe: 60, habilidadesPrimarias: ['Bola de fuego'], habilidadesDeSalvacion: ['Inteligencia'], nivel: 1 }
  ];

  seleccionarClase(clase: Clase) {
    this.claseSeleccionada.emit(clase);
    this.clases = this.clases.filter(c => c === clase);
  }
}
