import { ComponentFixture, TestBed } from '@angular/core/testing';

import { SelectorClaseComponent } from './selector-clase.component';

describe('SelectorClaseComponent', () => {
  let component: SelectorClaseComponent;
  let fixture: ComponentFixture<SelectorClaseComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [SelectorClaseComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(SelectorClaseComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
